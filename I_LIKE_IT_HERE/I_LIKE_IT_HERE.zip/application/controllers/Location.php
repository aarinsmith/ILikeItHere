<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * ++++++++++++++++++++++++++++++++++++++++++++++++++++++
 * 	Locations Controller.
 * 	Handles routes for posting and retrieving location
 * 	data to and from a users profile.
 *
 *	@author 	Aarin Smith
 *  @copyright 	2015, Aarin Smith
 * ++++++++++++++++++++++++++++++++++++++++++++++++++++++
 */
class Location extends CI_Controller
{
	// Very loose RESTful call to add a placeId to a user.
	public function addPlace()
	{
		$place = $this->input->post('placeId');
		$userId = $this->input->post('userId');

		$this->User->addLocation( $userId, $place );

		return "Sucessfully added to DB";
	}
}